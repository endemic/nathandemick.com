#pragma strict

function Start () {

}

function Update () {

}

function OnGUI() {
	var width = Screen.width;
	var height = Screen.height;

	if (GUI.Button(Rect(width / 2 - 50, height - height / 5, 100, 50), "Start!")) {
		Application.LoadLevel("Game");
	}
}