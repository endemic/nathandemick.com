// player.js
// #pragma strict enforces static typing in Unity Javascript
#pragma strict

// This public variable can be easily changed later in the Inspector
var moveSpeed:float = 5.0;

function Update () {
	// Get input from WASD or arrow keys (values from 0.0 - 1.0) and modify it by the "moveSpeed" variable
	// Also make framerate independent by multiplying by Time.deltaTime
	var x = Input.GetAxis("Horizontal") * moveSpeed * Time.deltaTime;
	var z = Input.GetAxis("Vertical") * moveSpeed * Time.deltaTime;
	
	// Modify the "transform" component of the GameObject this script is attached to
	// Translate (move) it along the X and Z axes. 
	// Y will always be zero because we only want to move in two dimensions
	transform.Translate(x, 0, z);
}