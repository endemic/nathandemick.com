//
//  MyAwesomeScene.m
//  SceneExample
//
//  Created by Nathan Demick on 12/1/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "MyAwesomeScene.h"
#import "HelloWorldScene.h"

@implementation MyAwesomeScene

- (id)init
{
	if ((self = [super init]))
	{
		// All this scene does upon initialization is init & add the layer class
		MyAwesomeLayer *layer = [MyAwesomeLayer node];
		[self addChild:layer];
	}
	
	return self;
}

- (void)dealloc
{
	// Nothing else to deallocate
	[super dealloc];
}

@end

@implementation MyAwesomeLayer

- (id)init
{
	// Since we extended CCColorLayer instead of regular ol' CCLayer,
	// we'll init the object with initWithColor. ccc4 takes rgba arguments - in 
	// this case it's a bright green background
	if ((self = [super initWithColor:ccc4(0, 255, 0, 255)]))
	{
		// Get window size
		CGSize size = [[CCDirector sharedDirector] winSize];
		
		// Add a button which takes us back to HelloWorldScene
		
		// Create a label with the text we want on the button
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Tap Here" fontName:@"Helvetica" fontSize:32.0];
		
		// Create a button out of the label, and tell it to run the "switchScene" method
		CCMenuItem *button = [CCMenuItemLabel itemWithLabel:label target:self selector:@selector(switchScene)];
		
		// Add the button to a menu - "nil" terminates the list of items to add
		CCMenu *menu = [CCMenu menuWithItems:button, nil];
		
		// Place the menu in center of screen
		[menu setPosition:ccp(size.width / 2, size.height / 2)];
		
		// Finally add the menu to the layer
		[self addChild:menu];
	}
	
	return self;
}

- (void)switchScene
{
	// Create a scene transition that uses the "RotoZoom" effect
	CCTransitionRotoZoom *transition = [CCTransitionRotoZoom transitionWithDuration:1.0 scene:[HelloWorld scene]];
	
	// Tell the director to run the transition
	[[CCDirector sharedDirector] replaceScene:transition];
}

- (void)dealloc
{
	// Nothing else to deallocate
	[super dealloc];
}

@end