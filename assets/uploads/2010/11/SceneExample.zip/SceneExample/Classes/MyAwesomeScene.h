//
//  MyAwesomeScene.h
//  SceneExample
//
//  Created by Nathan Demick on 12/1/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "cocos2d.h"

@interface MyAwesomeScene : CCScene {}
@end

// Extending CCColorLayer so that we can specify a 
// default background color other than black 
@interface MyAwesomeLayer : CCColorLayer {}
@end