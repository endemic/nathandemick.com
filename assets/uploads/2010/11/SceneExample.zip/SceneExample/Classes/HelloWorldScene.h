//
//  HelloWorldLayer.h
//  SceneExample
//
//  Created by Nathan Demick on 12/1/10.
//  Copyright Ganbaru Games 2010. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorld Layer
@interface HelloWorld : CCLayer
{
}

// returns a Scene that contains the HelloWorld as the only child
+(id) scene;

@end
