//
//  HelloWorldLayer.h
//  TouchExample
//
//  Created by Nathan Demick on 12/6/10.
//  Copyright Ganbaru Games 2010. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorld Layer
@interface HelloWorld : CCLayer
{
	// The sprite that we create in the center of the screen
	CCSprite *mySprite;
	
	// When a user pinches, we save the first value of the distance (in px) between their fingers
	float startingDistance;
	
	// Stores the previous pinch distance; used to figure out if the user shrinks their pinch after making it bigger, and vice versa
	float previousDistance;
	
	// Stores 1 or -1, depending on whether the pinch is growing or shrinking
	int direction;
}

// Declare these variables as properties of the HelloWorld class
@property (nonatomic, retain) CCSprite *mySprite;
@property float startingDistance;
@property float previousDistance;
@property int direction;

// returns a Scene that contains the HelloWorld as the only child
+(id) scene;

@end
