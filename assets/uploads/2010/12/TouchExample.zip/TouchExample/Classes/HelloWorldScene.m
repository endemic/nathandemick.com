//
//  HelloWorldLayer.m
//  TouchExample
//
//  Created by Nathan Demick on 12/6/10.
//  Copyright Ganbaru Games 2010. All rights reserved.
//

// Import the interfaces
#import "HelloWorldScene.h"

// HelloWorld implementation
@implementation HelloWorld

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorld *layer = [HelloWorld node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// Creates "setters" and "getters" for the properties declared in the .h file
@synthesize mySprite, startingDistance, previousDistance, direction;

// on "init" you need to initialize your instance
- (id)init
{
	if ((self = [super init]))
	{

		// ask director the the window size
		CGSize size = [[CCDirector sharedDirector] winSize];

		// Set layer to respond to touch events
		[self setIsTouchEnabled:TRUE];
		
		// Create sprite and add to layer
		mySprite = [CCSprite spriteWithFile:@"Icon.png"];
		[mySprite setPosition:ccp(size.width / 2, size.height / 2)];
		[self addChild:mySprite];
	}
	return self;
}

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	// Reset the value that stores the initial distance between touches
	startingDistance = 0;
	previousDistance = 0;
	direction = 0;
}

// Override the "ccTouchesMoved:withEvent:" method to add your own logic
- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	// This method is passed an NSSet of touches called (of course) "touches"
	// "allObjects" returns an NSArray of all the objects in the set
	NSArray *touchArray = [touches allObjects];

	// Only run the following code if there is more than one touch
	if ([touchArray count] > 1)
	{
		// We're going to track the first two touches (i.e. first two fingers)
		// Create "UITouch" objects representing each touch
		UITouch *fingerOne = [touchArray objectAtIndex:0];
		UITouch *fingerTwo = [touchArray objectAtIndex:1];
		
		// Convert each UITouch object to a CGPoint, which has x/y coordinates we can actually use
		CGPoint pointOne = [fingerOne locationInView:[fingerOne view]];
		CGPoint pointTwo = [fingerTwo locationInView:[fingerTwo view]];
		
		// The touch points are always in "portrait" coordinates
		// You will need to convert them if in landscape (which we are)
		pointOne = [[CCDirector sharedDirector] convertToGL:pointOne];
		pointTwo = [[CCDirector sharedDirector] convertToGL:pointTwo];

		// Get the distance between the touch points
		float distance = sqrt(pow(pointOne.x - pointTwo.x, 2.0) + pow(pointOne.y - pointTwo.y, 2.0));
		
		// If the starting distance value has been reset (unlikely that a user can place two fingers on top of each other)
		// then store the starting distance value so we can determine whether to shrink or enlarge the sprite
		if (startingDistance == 0)
		{
			startingDistance = distance;
			previousDistance = distance;
		}
		// Set whether the gesture is grow or shrink
		else if (direction == 0)
		{
			// Shrink
			if (previousDistance > distance)
				direction = -1;
			// Grow
			else
				direction = 1;
		}

		// Change from shrink to grow
		if (previousDistance > distance && direction == -1)
		{
			direction = 1;

			// Reset starting scale values
			startingDistance = distance;
			previousDistance = distance;
		}
		
		// Change from grow to shrink
		if (previousDistance < distance && direction == 1)
		{
			direction = -1;
			
			// Reset starting scale values
			startingDistance = distance;
			previousDistance = distance;
		}

		// Scale the distance based on the overall width of the screen (multiplied by a constant, just for effect)
		float scale = [mySprite scale] + (distance - startingDistance) / ([CCDirector sharedDirector].winSize.width * 2);
		
		// Set the scale factor of the sprite, only if it's not too big or too small
		if (scale > 0.5 && scale < 5)
			[mySprite setScale:scale];
		
		previousDistance = distance;
	}
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSLog(@"Touches ended!");
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
