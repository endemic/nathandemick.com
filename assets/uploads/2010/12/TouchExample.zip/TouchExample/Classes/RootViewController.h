//
//  RootViewController.h
//  TouchExample
//
//  Created by Nathan Demick on 12/6/10.
//  Copyright Ganbaru Games 2010. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
