//
//  GameScene.h
//  Asteroids
//
//  Created by Nathan Demick on 12/14/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "cocos2d.h"
#import "Ship.h"

@interface GameLayer : CCLayer
{
	// Arrays used to keep track of all visible asteroids/bullets
	NSMutableArray *asteroids;
	NSMutableArray *bullets;
	
	Ship *ship;
	
	// Used to determine the number of asteroids that appear 
	int currentLevel;
	
	// To determine rotation
	float previousTouchAngle, currentTouchAngle;
	
	// To determine movement/shooting
	CGPoint startTouchPoint, endTouchPoint;
}

+ (id)scene;
- (void)createAsteroidAt:(CGPoint)position withSize:(int)size;
- (void)createBullet;
- (void)startLevel;
- (void)resetShip;

@end