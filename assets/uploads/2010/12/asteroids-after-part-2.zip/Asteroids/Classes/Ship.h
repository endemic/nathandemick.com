//
//  Ship.h
//  Asteroids
//
//  Created by Nathan Demick on 12/14/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "cocos2d.h"

@interface Ship : CCSprite 
{
	// Store how fast the ship is moving
	CGPoint velocity;
}

@property CGPoint velocity;

// Have to override this method in order to subclass CCSprite
- (id)initWithTexture:(CCTexture2D *)texture rect:(CGRect)rect;

// This method gets called each time the object is updated in the game loop
- (void)update:(ccTime)dt;

@end
