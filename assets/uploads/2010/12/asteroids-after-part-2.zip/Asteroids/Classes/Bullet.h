//
//  Bullet.h
//  Asteroids
//
//  Created by Nathan Demick on 12/14/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "cocos2d.h"

@interface Bullet : CCSprite 
{
	// Stores how far the bullet has moved!
	float distanceMoved;
	
	// How fast the bullet moves
	CGPoint velocity;
	
	// Whether or not the bullet has traveled so far that it disappears
	bool expired;
}

// Declare properties so setters/getters can be automatically synthesized
@property float distanceMoved;
@property CGPoint velocity;
@property bool expired;

// Declare methods
- (id)initWithTexture:(CCTexture2D *)texture rect:(CGRect)rect;
- (void)update:(ccTime *)dt;

@end
