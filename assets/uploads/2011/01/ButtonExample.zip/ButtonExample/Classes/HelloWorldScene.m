//
//  HelloWorldLayer.m
//  ButtonExample
//
//  Created by Nathan Demick on 1/13/11.
//  Copyright Ganbaru Games 2011. All rights reserved.
//

// Import the interfaces
#import "HelloWorldScene.h"

// HelloWorld implementation
@implementation HelloWorld

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorld *layer = [HelloWorld node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init] )) 
	{
		CGSize windowSize = [CCDirector sharedDirector].winSize;
		
		// Create a button (aka "menu item"), have it execute the "buttonOneAction" method when tapped
		CCMenuItemFont *buttonOne = [CCMenuItemFont itemFromString:@"Tap Here!" target:self selector:@selector(buttonOneAction:)];
		
		// An alternate way of doing the same thing, using a "block"
//		CCMenuItemFont *buttonOne = [CCMenuItemFont itemFromString:@"Tap Here!" block:^(id sender)
//		{
//			// Get a reference to the button that was tapped
//			CCMenuItemFont *button = (CCMenuItemFont *)sender;
//			
//			// Have the button spin around!
//			[button runAction:[CCRotateBy actionWithDuration:1 angle:360]];
//		}];
		
		// Specify font details
		[CCMenuItemFont setFontSize:32];
		[CCMenuItemFont setFontName:@"Helvetica"];
		
		// Create second button using image files
		CCMenuItemImage *buttonTwo = [CCMenuItemImage itemFromNormalImage:@"button-normal.png" selectedImage:@"button-selected.png" disabledImage:@"button-disabled.png" block:^(id sender)
		{
			// Get a reference to the button that was tapped
			CCMenuItemImage *button = (CCMenuItemImage *)sender;
			
			// Move the button around
			CCJumpBy *action = [CCJumpBy actionWithDuration:1 position:ccp(windowSize.width / 3, windowSize.height / 3) height:25 jumps:2];
			[button runAction:[CCSequence actions:action, [action reverse], nil]];
		}];
		
		// Create on/off buttons to go in toggle group
		CCMenuItemFont *buttonThree = [CCMenuItemFont itemFromString:@"ON"];
		CCMenuItemFont *buttonFour = [CCMenuItemFont itemFromString:@"OFF"];
		
		// Create toggle group
		CCMenuItemToggle *toggleGroup = [CCMenuItemToggle itemWithBlock:^(id sender)
		{ 
			NSLog(@"Selected button: %i", [(CCMenuItemToggle *)sender selectedIndex]); 
		} items:buttonThree, buttonFour, nil];
		
		// Create menu w/ three buttons - two "menu items" & one "menu item toggle"
		CCMenu *myMenu = [CCMenu menuWithItems:buttonOne, buttonTwo, toggleGroup, nil];
		
		// Position menu at center of screen
		[myMenu setPosition:ccp(windowSize.width / 2, windowSize.height / 2)];
		
		// Align buttons in a single column w/ 20px padding around 'em
		[myMenu alignItemsVerticallyWithPadding:20.0];
		
		// Add menu to layer
		[self addChild:myMenu z:1];
	}
	return self;
}

- (void)buttonOneAction:(id)sender
{
	// Get a reference to the button that was tapped
	CCMenuItemFont *button = (CCMenuItemFont *)sender;

	// Have the button spin around!
	[button runAction:[CCRotateBy actionWithDuration:1 angle:360]];
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
