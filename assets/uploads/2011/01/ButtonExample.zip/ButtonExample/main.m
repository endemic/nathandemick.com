//
//  main.m
//  ButtonExample
//
//  Created by Nathan Demick on 1/13/11.
//  Copyright Ganbaru Games 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"ButtonExampleAppDelegate");
	[pool release];
	return retVal;
}
