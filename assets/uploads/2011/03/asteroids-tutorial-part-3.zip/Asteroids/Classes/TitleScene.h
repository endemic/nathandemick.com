//
//  TitleScene.h
//  Asteroids
//
//  Created by Nathan Demick on 12/14/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "cocos2d.h"

@interface TitleLayer : CCLayer { }

+ (id)scene;

@end