//
//  ScoresScene.h
//  Asteroids
//
//  Created by Nathan Demick on 2/21/11.
//  Copyright 2011 Ganbaru Games. All rights reserved.
//

#import "cocos2d.h"

@interface ScoresLayer : CCLayer { }

+ (id)scene;

@end
