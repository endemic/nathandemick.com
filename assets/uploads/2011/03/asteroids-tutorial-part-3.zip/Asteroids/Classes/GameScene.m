//
//  GameScene.m
//  Asteroids
//
//  Created by Nathan Demick on 12/14/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "GameScene.h"
#import "Ship.h"
#import "Asteroid.h"
#import "Bullet.h"
#import "GameConfig.h"
#import "TitleScene.h"

@implementation GameLayer

+ (id)scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	GameLayer *layer = [GameLayer node];
	
	// add layer as a child to scene
	[scene addChild:layer];
	
	// return the scene
	return scene;
}

- (id)init
{
	if ((self = [super init]))
	{
		[self setIsTouchEnabled:TRUE];

		// Schedule the update method in this layer
		[self scheduleUpdate];
		
		// Get window size
		CGSize windowSize = [CCDirector sharedDirector].winSize;
		
		// Create ship object and add it to layer
		ship = [Ship spriteWithFile:@"ship.png"];
		[self addChild:ship];
		
		// Create label to show player score
		pointsDisplay = [CCLabelTTF labelWithString:@"0" fontName:@"Courier" fontSize:32.0];
		[pointsDisplay setPosition:ccp(windowSize.width - 20, windowSize.height - 20)];
		[pointsDisplay setColor:ccc3(255, 255, 255)];
		[self addChild:pointsDisplay z:1];
		
		// Initialize arrays that will be used to store other game objects
		asteroids = [[NSMutableArray array] retain];
		bullets = [[NSMutableArray array] retain];
		
		// Call method which positions the ship and creates asteroids
		[self startLevel];
	}
	return self;
}

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	// This method is passed an NSSet of touches called (of course) "touches"
	// The "allObjects" method returns an NSArray of all the objects in the set
	NSArray *touchArray = [touches allObjects];
	
	// Only run the following code if there is more than one touch
	if ([touchArray count] > 0)
	{
		// Create "UITouch" objects representing each touch
		UITouch *fingerOne = [touchArray objectAtIndex:0];
		
		// Convert each UITouch object to a CGPoint, which has x/y coordinates we can actually use
		CGPoint pointOne = [fingerOne locationInView:[fingerOne view]];
		
		// The touch points are always in "portrait" coordinates - convert to landscape
		pointOne = [[CCDirector sharedDirector] convertToGL:pointOne];
		
		// We store the starting point of the touch so we can determine whether the touch is a swipe or tap.
		// A tap shouldn't move, so we compare the distance of the starting/ending touches, and if the distance is
		// small enough (we account for a bit of movement, just in case), the input is considered a tap
		startTouchPoint = pointOne;
		
		// Only run the following code if there is more than one touch
		if ([touchArray count] > 1)
		{
			// Create "UITouch" objects representing each touch
			UITouch *fingerTwo = [touchArray objectAtIndex:1];
			
			// Convert each UITouch object to a CGPoint, which has x/y coordinates we can actually use
			CGPoint pointTwo = [fingerTwo locationInView:[fingerTwo view]];
			
			// The touch points are always in "portrait" coordinates - convert to landscape
			pointTwo = [[CCDirector sharedDirector] convertToGL:pointTwo];
			
			// Initialize the variables used to store the angle of rotation derived from the user's fingers
			currentTouchAngle = previousTouchAngle = CC_RADIANS_TO_DEGREES(atan2(pointOne.x - pointTwo.x, pointOne.y - pointTwo.y));
		}
	}
}

- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	// This method is passed an NSSet of touches called (of course) "touches"
	// "allObjects" returns an NSArray of all the objects in the set
	NSArray *touchArray = [touches allObjects];
	
	// Only run the following code if there is more than one touch
	if ([touchArray count] > 1)
	{
		// We're going to track the first two touches (i.e. first two fingers)
		// Create "UITouch" objects representing each touch
		UITouch *fingerOne = [touchArray objectAtIndex:0];
		UITouch *fingerTwo = [touchArray objectAtIndex:1];
		
		// Convert each UITouch object to a CGPoint, which has x/y coordinates we can actually use
		CGPoint pointOne = [fingerOne locationInView:[fingerOne view]];
		CGPoint pointTwo = [fingerTwo locationInView:[fingerTwo view]];
		
		// The touch points are always in "portrait" coordinates - you will need to convert them if in landscape (which we are)
		pointOne = [[CCDirector sharedDirector] convertToGL:pointOne];
		pointTwo = [[CCDirector sharedDirector] convertToGL:pointTwo];
		
		// Get the angle that's created by the user's two fingers - see http://en.wikipedia.org/wiki/Atan2
		currentTouchAngle = CC_RADIANS_TO_DEGREES(atan2(pointOne.x - pointTwo.x, pointOne.y - pointTwo.y));
		
		// Compare with the previous angle, to decide whether the change is positive or negative.
		float difference = currentTouchAngle - previousTouchAngle;
		
		// The ship is then rotated by that difference
		ship.rotation += difference;

		// Store the current angle variable to be used again on the next loop iteration
		previousTouchAngle = currentTouchAngle;
	}
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	// Get array of touch objects
	NSArray *touchArray = [touches allObjects];
	
	// Only run this if there's one touch
	if ([touchArray count] == 1)
	{
		// Create "UITouch" objects representing each touch
		UITouch *fingerOne = [touchArray objectAtIndex:0];
		
		// Convert each UITouch object to a CGPoint, which has x/y coordinates we can actually use
		CGPoint pointOne = [fingerOne locationInView:[fingerOne view]];
		
		// The touch points are always iin "portrait" coordinates - convert to landscape
		pointOne = [[CCDirector sharedDirector] convertToGL:pointOne];
		
		// Set the variable that stores the ending touch point
		endTouchPoint = pointOne;
		
		// Get the distance that the user's finger moved during this touch
		float distance = sqrt(pow(endTouchPoint.x - startTouchPoint.x, 2) + pow(endTouchPoint.y - startTouchPoint.y, 2));
		
		// If the distance moved (in pixels) is small enough, consider the gesture a tap
		if (distance < 5)
		{
			// Shoot!
			[self createBullet];
		}
		// Otherwise, it's a swipe
		else
		{
			// Use distance of swipe as a multiplier for the ship velocity (longer swipe, go faster)
			ship.velocity = ccp(cos(CC_DEGREES_TO_RADIANS(ship.rotation)) * distance / 100, -sin(CC_DEGREES_TO_RADIANS(ship.rotation)) * distance / 100);
		}

	}
}

// Mostly handles collision detection
- (void)update:(ccTime)dt
{
	// If there are no more asteroids left, increment the level counter and start the new level
	if ([asteroids count] == 0)
	{
		currentLevel++;
		[self startLevel];
	}
	
	// Check for collisions vs. asteroids
    for (int i = 0; i < [asteroids count]; i++)
	{
        Asteroid *a = [asteroids objectAtIndex:i];
        
		// Check if asteroid hits ship
		if ([a collidesWith:ship])
		{
			// Game over, man!
			[self gameOver];
		}
		
		// Check if asteroid hits bullet, or if bullet is expired
        for (int j = 0; j < [bullets count]; j++)
		{
            Bullet *b = [bullets objectAtIndex:j];
            
			if (b.expired)
			{
				// Remove the bullet from organizational array
                [bullets removeObjectAtIndex:j];
                j--;
				
				// Remove bullet sprite from layer
				[self removeChild:b cleanup:NO];
			}
			else if ([a collidesWith:b])
			{
				// Remove the asteroid the bullet collided with
                [asteroids removeObjectAtIndex:i];
                i--;
				
				// Remove asteroid sprite from layer
				[self removeChild:a cleanup:NO];
				
				// Remove the bullet the asteroid collided with
                [bullets removeObjectAtIndex:j];
                j--;
				
				// Remove bullet sprite from layer
				[self removeChild:b cleanup:NO];
				
				// Increment player score
				points += 10;
				[pointsDisplay setString:[NSString stringWithFormat:@"%i", points]];
				
				// Create two new asteroids in the place of the destroyed one, if the destroyed one wasn't already the smallest
				if (a.size < kAsteroidSmall) 
				{
					for (int i = 0; i < 2; i++)
						[self createAsteroidAt:a.position withSize:a.size + 1];
				}
			}	// End bullet/asteroid collision check
		}	// End bullet loop
		
	}	// End asteroid loop
}

- (void)createAsteroidAt:(CGPoint)position withSize:(int)size
{
	// Decide which image file to use for the new asteroid
	NSString *imageFile;
	switch (size) 
	{
		default:
		case kAsteroidLarge:
			imageFile = @"asteroid-large.png";
			break;
		case kAsteroidMedium:
			imageFile = @"asteroid-medium.png";
			break;
		case kAsteroidSmall:
			imageFile = @"asteroid-small.png";
			break;
	}
	
	// Create a new asteroid object using the appropriate image file
	Asteroid *a = [Asteroid spriteWithFile:imageFile];
	
	// Set the size and position
	a.size = size;
	a.position = position;
	
	// Random numbers - see http://stackoverflow.com/questions/160890/generating-random-numbers-in-objective-c
	a.velocity = ccp((float)(arc4random() % 100) / 100 - 1, (float)(arc4random() % 100) / 100 - 1);
	
	// Add asteroid to organizational array
	[asteroids addObject:a];
	
	// Add asteroid to layer
	[self addChild:a];
}

- (void)createBullet
{
	// Create a new asteroid object using the appropriate image file
	Bullet *b = [Bullet spriteWithFile:@"bullet.png"];
	
	// Set the bullet's position by starting w/ the ship's position, then adding the rotation vector, so the bullet appears to come from the ship's nose
	b.position = ccp(ship.position.x + cos(CC_DEGREES_TO_RADIANS(ship.rotation)) * ship.contentSize.width, ship.position.y - sin(CC_DEGREES_TO_RADIANS(ship.rotation)) * ship.contentSize.height);
	
	// Set the bullet's velocity to be in the same direction as the ship is pointing, plus whatever the ship's velocity is
	b.velocity = ccp(cos(CC_DEGREES_TO_RADIANS(ship.rotation)) * 2 + ship.velocity.x, -sin(CC_DEGREES_TO_RADIANS(ship.rotation)) * 2 + ship.velocity.y);
	
	// Add bullet to organizational array
	[bullets addObject:b];
	
	// Add bullet to layer
	[self addChild:b];
}

- (void)startLevel
{
	// Reset the ship's position, which also removes all bullets
	[self resetShip];

	// Get window size
	CGSize windowSize = [CCDirector sharedDirector].winSize;
	
	// Create asteroids based on level number
	for (int i = 0; i < (currentLevel + 2); i++)
	{
		// Random numbers - see http://stackoverflow.com/questions/160890/generating-random-numbers-in-objective-c
		CGPoint randomPointOnScreen = ccp((float)(arc4random() % 100) / 100 * windowSize.width, (float)(arc4random() % 100) / 100 * windowSize.height);

		[self createAsteroidAt:randomPointOnScreen withSize:kAsteroidLarge];
	}
}

- (void)resetShip
{
	// Reset ship position/speed
	CGSize windowSize = [CCDirector sharedDirector].winSize;
	ship.position = ccp(windowSize.width / 2, windowSize.height / 2);
	ship.velocity = ccp(0, 0);
	
	// Remove all existing bullets from layer
	for (Bullet *b in bullets)
		[self removeChild:b cleanup:NO];
	
	// Empty out bullet-storing array
	[bullets removeAllObjects];
}

- (void)gameOver
{
	// Reset the ship's position, which also removes all bullets
	[self resetShip];
	
	// Hide ship
	ship.visible = NO;
	
	// Get window size
	CGSize windowSize = [CCDirector sharedDirector].winSize;
	
	// Show "game over" text
	CCLabelTTF *title = [CCLabelTTF labelWithString:@"game over" fontName:@"Courier" fontSize:64.0];
	
	// Position title at center of screen
	[title setPosition:ccp(windowSize.width / 2, windowSize.height / 2)];
	
	// Add to layer
	[self addChild:title z:1];
	
	// Create button that will take us back to the title screen
	CCMenuItemFont *backButton = [CCMenuItemFont itemFromString:@"back to title" target:self selector:@selector(backButtonAction)];
	
	// Create menu that contains our button
	CCMenu *menu = [CCMenu menuWithItems:backButton, nil];
	
	// Set position of menu to be below the "game over" text
	[menu setPosition:ccp(windowSize.width / 2, title.position.y - title.contentSize.height)];
	
	// Add menu to layer
	[self addChild:menu z:2];
	
	// Get scores array stored in user defaults
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	
	// Get high scores array from "defaults" object
	NSMutableArray *highScores = [NSMutableArray arrayWithArray:[defaults arrayForKey:@"scores"]];
	
	// Iterate thru high scores; see if current point value is higher than any of the stored values
	for (int i = 0; i < [highScores count]; i++)
	{
		if (points >= [[highScores objectAtIndex:i] intValue])
		{
			// Insert new high score, which pushes all others down
			[highScores insertObject:[NSNumber numberWithInt:points] atIndex:i];
			
			// Remove last score, so as to ensure only 5 entries in the high score array
			[highScores removeLastObject];
			
			// Re-save scores array to user defaults
			[defaults setObject:highScores forKey:@"scores"];
			
			[defaults synchronize];
			
			NSLog(@"Saved new high score of %i", points);
			
			// Bust out of the loop 
			break;
		}
	}
}

- (void)backButtonAction
{
	NSLog(@"Switch to TitleScene");
	[[CCDirector sharedDirector] replaceScene:[TitleLayer scene]];
}

- (void)dealloc
{
	// Release all the objects that have been retained in this class
	[asteroids release];
	[bullets release];

	[super dealloc];
}
@end