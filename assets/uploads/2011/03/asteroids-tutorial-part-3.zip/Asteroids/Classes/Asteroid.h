//
//  Asteroid.h
//  Asteroids
//
//  Created by Nathan Demick on 12/14/10.
//  Copyright 2010 Ganbaru Games. All rights reserved.
//

#import "cocos2d.h"

@interface Asteroid : CCSprite 
{
	// Stores the size of the asteroid - values will be 1, 2, or 3
	int size;
	
	// A struct that holds X/Y values that will be used for the asteroid's speed
	CGPoint velocity;
}

// Declare properties so setters/getters can be automatically synthesized
@property int size;
@property CGPoint velocity;

// Declare methods
- (id)initWithTexture:(CCTexture2D *)texture rect:(CGRect)rect;
- (void)update:(ccTime)dt;
- (bool)collidesWith:(CCSprite *)obj;

@end
